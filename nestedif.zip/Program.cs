﻿// See https://aka.ms/new-console-template for more information
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter your age: ");
        int age = int.Parse(Console.ReadLine());

        if (age >= 18 && age <= 65)
        {
            Console.Write("Enter your education level (1-5): ");
            int education = int.Parse(Console.ReadLine());

            if (education >= 3)
            {
                Console.Write("Do you have any work experience? (yes/no): ");
                string experience = Console.ReadLine().ToLower();

                if (experience == "yes")
                {
                    Console.WriteLine("Congratulations! You are eligible for a job.");
                }
                else if (experience == "no")
                {
                    Console.WriteLine("Sorry, you need work experience to be eligible for a job.");
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                }
            }
            else
            {
                Console.WriteLine("Sorry, you need to have a certain level of education to be eligible for a job.");
            }
        }
        else
        {
            Console.WriteLine("Sorry, you are not of eligible age for a job.");
        }
    }
}
