﻿// See https://aka.ms/new-console-template for more information
using System;
namespace Conditional
{
    class IfStatement
    {
        public static void Main(string[] args)
        {
            int value = 3;
            if (value < 10)
            {
                Console.WriteLine("{0} is less than 10", value);
            }
            else
            {
                Console.WriteLine("{0} is greater than 10", value);
            }
        }
    }
}


